package pack;

import java.io.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MultiThreadFileProcessor {
    public static void main(String[] args) throws IOException, InterruptedException {
        String inputFile = "input.txt";
        String outputFile = "output.txt";


        BlockingQueue<String> queue = new LinkedBlockingQueue<>();
        int threadCount = 3;

        // Массив для подсчета количества выбранного слова
        int[] selectedWordCount = new int[threadCount];


        Thread[] threads = new Thread[threadCount];

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            threads[i] = new Thread(() -> {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
                    String line;
                    while ((line = queue.poll()) != null || !Thread.currentThread().isInterrupted()) {
                        if (line != null) {
                            // + Префикс
                            String processedLine = "Поток " + (threadId + 1) + ": " + line;

                            // Подсчет количества повторений выбранного слова
                            String lowerCaseLine = line.toLowerCase();
                            selectedWordCount[threadId] += (lowerCaseLine.length() - lowerCaseLine.replace("ночь", "").length()) / 4;

                            // Запись в файл + вывод в консоль
                            writer.write(processedLine);
                            writer.newLine();
                            System.out.println(processedLine);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            threads[i].start();
        }

        // Чтение файла главным потоком
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                queue.put(line);
            }
        }

        // Streams end
        for (Thread thread : threads) {
            thread.interrupt();
        }
        for (Thread thread : threads) {
            thread.join();
        }

        // Подсчет количества повторений выбранного слова
        int totalSpringCount = 0;
        for (int count : selectedWordCount) {
            totalSpringCount += count;
        }

        try (FileWriter writer = new FileWriter("output.txt", true)) { // true - чтобы не перезаписать файл
            writer.write("Общее количество слова 'ночь': " + totalSpringCount + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Общее количество слова 'ночь': " + totalSpringCount);
    }
}
