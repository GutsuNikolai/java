package pack;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.io.*;


public class MultiThreading {
    public static void main(String[] args) throws  InterruptedException{
        final String inputFile = "input.txt"; // Укажи путь к своему файлу
        final String outputFile = "output.txt";
        int numberOfThreads = 3;
        int[] totalCount = new int[numberOfThreads];

        BlockingQueue<String> queue= new LinkedBlockingQueue<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                queue.put(line);
            }
        } catch (IOException e) {
            e.printStackTrace(); // Обработка ошибок
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", false))) {
            // Очистка файла
        } catch (IOException e) {
            e.printStackTrace();
        }

        Thread [] threads = new Thread[numberOfThreads];

        for (int i = 0; i < numberOfThreads; i++){
            threads[i] = new Thread(new Worker(queue, i+1, totalCount));
            threads[i].start();
        }

        for (int i = 0; i < numberOfThreads; i++) {
            queue.put("END");  // маркер для завершения работы потоков
        }

        for (int i = 0; i < numberOfThreads; i++) {
            threads[i].join();
        }


        int finalCount = 0;
        for (int i = 0; i < numberOfThreads; i++){
            finalCount += totalCount[i];
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", true))) {
            writer.write("Всего вхождений слова ночь: " + finalCount);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("All threads have finished processing.\n" + "Total count of word \'ночь\':" + finalCount);

    }


}
