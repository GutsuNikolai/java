package pack;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;

public class Worker implements Runnable {
    private final BlockingQueue<String> queue;
    private final int workerId;
    private final int[] count;
    String word  = "ночь";

    public Worker(BlockingQueue<String> queue, int workerId, int [] countOfWord){
        this.queue = queue;
        this.workerId = workerId;
        this.count = countOfWord;
    }


    public void  run() {
        try {
            while(true){
                String task = queue.take();
                if (task.equals("END")) break;


                proccessTask(task);

            }
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();
            System.err.println("Thread " + workerId + " was interrupted");
        }

    }

    public void proccessTask(String task){
        System.out.println("Thread " + workerId + ":" + task);
        count [workerId - 1] += task.split(word, -1).length - 1;

        try(BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", true))){
            writer.write("Thread " + workerId + ":" + task + "\n");
        }catch (IOException e){
            e.printStackTrace();
        }
    }


}