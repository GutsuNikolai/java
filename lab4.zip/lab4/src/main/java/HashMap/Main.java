package HashMap;

public class Main {
    public static void main(String[] args) {

        MyHashMap<String, Integer> myHashMap = new MyHashMap<String, Integer>();

        // Тесты
        // 1. Добавление элементов
        myHashMap.put("One", 1);
        myHashMap.put("Two", 2);
        myHashMap.put("Three", 3);

        // 2. Метод Get
        Integer valueOne = myHashMap.get("One");
        System.out.println("Value for 'One': " + valueOne);

        // 3. Проверка для несуществующего элемента
        Integer valueFour = myHashMap.get("Four");
        System.out.println("Value for 'Four': " + valueFour);

        // 4. Метод delete
        boolean deleted = myHashMap.delete("Two");
        System.out.println("Deleted 'Two': " + deleted);

        // 5. Попытка получить удаленный элемент
        Integer valueTwoAfterDeletion = myHashMap.get("Two");
        System.out.println("Value for 'Two' after deletion: " + valueTwoAfterDeletion);

        // 6. Удаления несуществующего элемента
        boolean deletedNonExistent = myHashMap.delete("Four");
        System.out.println("Deleted 'Four': " + deletedNonExistent);
        myHashMap.print();
    }
}
