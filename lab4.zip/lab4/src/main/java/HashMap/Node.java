package HashMap;
import java.util.Objects;

public class Node<K,V> {
    K key;
    V value;

    public Node(K key, V value) {
        this.key = key;
        this.value = value;
    }

    // Переорпределяю equals & hashCode для корректного сравения и добавления в коллекцию
    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node<K,V> node = (Node<K,V>)o;
        return key.equals(node.key) && value.equals(node.value);
    }

    @Override
    public int hashCode(){
        return Objects.hash(key,value);
    }

    @Override
    public String toString() {
        return "{" + key + " : " + value + '}';
    }
}
