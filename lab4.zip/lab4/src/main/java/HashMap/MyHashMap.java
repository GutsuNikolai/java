package HashMap;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.TreeMap;

public class MyHashMap<K,V> {
    private int initialCapacity = 16;
    private float loadFactor = 0.75f;
    private ArrayList<Object> table;

    public MyHashMap(){
        table = new ArrayList<>(initialCapacity);
        for (int i = 0; i < initialCapacity; i++){
            table.add(null);
        }
    }


    public int getIndex(K key){
        return key.hashCode() % initialCapacity;

    }

    public void put(K key ,V value ){


        int index = getIndex(key);
        // Объявляю bucket для проверки текущей ячейки массива на принадлежность к опрделенному классу
        Object bucket = table.get(index);

        if (bucket == null){ /* Если пусто  создаю там LInkedList (через приведение типов создаю переменную,
            чтоб можно было использовать методы LinkedList'а. То есть с table[index] обращаюсь  как с LinkdeList, несмотря на то
             что он все еще по факту Object. (приведение классов)*/
            table.set(index, new LinkedList<Node<K,V>>()); //
            LinkedList<Node<K,V>> linkedList = (LinkedList<Node<K,V>>) table.get(index); // сам элемент, для работы от имени LL
            linkedList.add(new Node<>(key, value));
        }else if (bucket instanceof LinkedList){ // Если там уже есть LL то либо добавляю элемент, либо делаю из него TM
            LinkedList<Node<K,V>> linkedList = (LinkedList<Node<K,V>>) table.get(index);
            if (linkedList.size() <  8){
                if (linkedList.stream().noneMatch(node -> node.key.equals(key))) {
                    linkedList.add(new Node<>(key, value));
                }
            } else{//Если это LL, и 8 элементов, то делаю из него TM

                TreeMap<K,V> tree = new TreeMap<>();
                for (Node<K,V> item: linkedList){ // Из LL добаляю элементы в  treeMap
                    tree.put(item.key, item.value);
                }
                tree.put(key,value);// также помещаю новый элемент
                table.set(index, tree);//В table помещаю TreeMap вместо LL
            }
        }else{
            TreeMap<K,V> treeMap = (TreeMap<K,V>)table.get(index);// Просто добавляю новый элемент в TM
            treeMap.put(key, value);
        }
    }

    // получение значения по ключу
    // комментировать не буду, тут все думаю понятно
    public V get(K key){
        int index = getIndex(key);
        Object bucket = table.get(index);

        if (bucket instanceof LinkedList){
            LinkedList<Node<K,V>> list = (LinkedList<Node<K,V>>)bucket;
            for (Node<K,V> item: list){
                if (item.key.equals(key)) return item.value;
            }
        }else if (bucket instanceof TreeMap){
            TreeMap<K,V> tree = (TreeMap<K,V>)bucket;
            return tree.get(key);
        }
        return null;
    }

    // Удаление элемета из коллекции
    public boolean delete(K key){
        int index = getIndex(key);
        Object bucket = table.get(index);

        if (bucket instanceof LinkedList){
            LinkedList<Node<K,V>> list = (LinkedList<Node<K,V>>)bucket;
            for (Node<K,V> item: list){
                if (item.key.equals(key)){
                    list.remove(item);
                    return true;
                }
            }
        }else if (bucket instanceof TreeMap){
            TreeMap<K,V> tree = (TreeMap<K,V>)bucket;
            if (tree.remove(key) != null)
                return true;
        }
        return false;
    }

    public void print(){
        for (Object bucket: table){
            if (bucket != null && bucket instanceof LinkedList){
                LinkedList<Node<K,V>> list = (LinkedList<Node<K,V>>)bucket;
                System.out.println(list);
            }
            if (bucket != null && bucket instanceof TreeMap){
                TreeMap<K,V> tree = (TreeMap<K,V>)bucket;
                System.out.println(tree);
            }
        }

    }
}
