package edu.java.developmt;

// Переопределяю методы родительского класса
class Dog extends Animal{

    @Override
    public void voice() {
        System.out.println("Gav");
    }

    @Override
    public void move() {
        System.out.println("The dog moves rapidly");
    }

    @Override
    public String toString(){
        return "Dog";
    }

}