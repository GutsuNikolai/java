package edu.java.developmt;

public class Main {
    public static void main(String[] args) {
        Animal[] animals = new Animal[4];
        animals[0] = new Cat();
        animals[1] = new Dog();
        animals[2] = new Racoon();
        animals[3] = new Cat();
        // Демонтрация работы методов объектов всех классов
        for (Animal animal:animals){
            System.out.println(animal);
            animal.move();
            animal.voice();
            System.out.println(animal.isUnic(animal, animals));
            System.out.println("_________________");
        }
        // Объекты интерфейсов создавать напрямую нельзя, но можно создать ссылку на такой объект
        // Так как у меня все классы дочерние реализуют оба интерфейса, могу создать ссылку на объект любого дочернего Animal класса

        Soundable[] soundables = new Soundable[]{new Cat()};
        Movable[] movables = new Movable[]{new Racoon()};

        // Демонстрация работы методов даннных объектов
        System.out.println(soundables[0]);
        soundables[0].voice();
        System.out.println(movables[0]);
        movables[0].move();
        Soundable a = soundables[0];

    }
}