package edu.java.developmt;

// Переопределяю методы родительского класса
class Cat extends Animal {

    @Override
    public void move() {
        System.out.println("The cat moves carefully");
    }

    @Override
    public void voice() {
        System.out.println("Meow");
    }

    @Override
    public String toString() {
        return "Cat";
    }

}