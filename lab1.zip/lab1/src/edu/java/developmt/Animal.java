package edu.java.developmt;

//Абстрактный родительский класс, который обязует дочерние реализоть/переопределить в себе методы toString() & equals(),
// и реализовать интерфейсы Movable & Soundable
public abstract class Animal implements Movable, Soundable{

    //  toString объявляю абстрактным, так как данный метод должен быть переопределен в каждом классе (so i want)
    @Override
    public abstract String toString();

    // equals должен будет просто проверять, относятли ли объекты к одному классу или нет
    @Override
    public boolean equals(Object object){
        if (this == object) return true; //если вдруг это один и тот же объект
        return(this.getClass() == object.getClass()); // если разные объекты, но экземпляры одного класса
    }

    // Для демонстрации работы метода equals: проверяет, если в списке только один экземпляр определнного класса.
    public String isUnic(Animal object, Animal[] animals){
        int count = 0;
        for (Animal animal: animals){
            if ((object.getClass().isInstance(animal)) & ( count <= 1 )) count++;
            else break;
        }
        return count > 1 ? "There are many " + object +  "'s in list!"
                        : "There is the only one " + object + " in list!";
    }
}
