package edu.java.developmt;
// Переопределяю методы родительского класса
public class Racoon extends Animal{

    @Override
    public void voice() {
        System.out.println("I dkn what he says");
    }

    @Override
    public void move() {
        System.out.println("Racoon is lazy and do not moves. He sleeps.");
    }

    @Override
    public String toString() {
        return "Racoon";
    }

}
