package edu.java.developmt;

public interface Movable {
    void move();
}
