package edu.java.developmt;

public interface Soundable {
    void voice();
}
