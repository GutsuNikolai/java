package lab3;

import java.security.interfaces.DSAPublicKey;

public class Main {
    public static void main(String[] args){
        LinkedList<Integer> list = new LinkedList<>();
        list.append(5);
        list.append(3);
        list.append(10);

        list.printList();
        list.addFirst(0);

        System.out.println("Size: " + list.size());
        System.out.println("Is empty: " + list.isEmpty());
        System.out.println("Node \"10\"" + list.find(10));

        list.delete(0);
        list.printList();
        list.clear();
        list.printList();

        System.out.println("--------------");
        doubleLinkedList<Integer> dlist = new doubleLinkedList<>();
        dlist.append(5);
        dlist.append(3);
        dlist.append(7);
        dlist.append(6);
        dlist.append(10);

        dlist.printList();
        dlist.addFirst(0);

        System.out.println("Size: " + dlist.size());
        System.out.println("Is empty: " + dlist.isEmpty());
        System.out.println("Node \"10\"" + dlist.find(10));

        dlist.delete(5);
        dlist.printList();
        dlist.clear();
        dlist.printList();
    }
}
