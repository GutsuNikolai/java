package lab3;

public class doubleLinkedList<T> {
    private Node<T> head;
    private Node<T> tail;

    public doubleLinkedList(){
        // При создании список пуст
        this.head = null;
        this.tail = null;
    }

    /* Добавление нового элемента:
        1- если первый: меняю сслку для next; previous остается null
        2- если последний: previous - меняется, next = null
        3- если в середину: меняются и next и previous
     */
    public void append(T data){
        Node<T> newNode = new Node<>(data);
        Node<T> current = tail;

        if (head == null){
            head = newNode;
            tail = newNode;
            return;
        }
        current.next = newNode;
        newNode.previous = current;
        tail = newNode;
    }
    // Поочередно вывожу все элементы
    public void printList(){
        if (head == null){
            System.out.println("List is empty!");
            return;
        }
        Node<T> current = head;
        System.out.print("[");
        while (current.next != null){
            System.out.print(current.data + ",");
            current = current.next;
        }
        System.out.println(current.data + "]");
    }

    public void delete(T data){
        Node<T> current = head;

        while (current != null && current.data != data) {
            current = current.next;
        }

        if (current == null) {
            // Элемент не найден
            return;
        }

        if (current == head){
            head = current.next;
            if (head != null){
                head.previous = null;
            } else {
                tail = null;
            }
        } else if (current == tail){
            tail = current.previous.next = null ;
        }else {
            if (current.previous != null) {
                current.previous.next = current.next;
            }
            if (current.next != null) {
                current.next.previous = current.previous;
            }
        }
    }

    public void addFirst(T data){
        Node<T> newNode = new Node(data);
        newNode.next = head;
        head.previous = newNode;
        head = newNode;

    }

    public boolean find(T data){
        Node<T> current = head;

        while (current != null){
            if (current.data == data)
                return true;
            current = current.next;
        } return false;
    }

    public int size(){
        Node<T> current = head;
        int count = 0;

        while(current != null){
            count++;
            current = current.next;
        } return count;
    }

    public boolean isEmpty(){
        return head == null;
    }

    public void clear(){
        head = null;
    }
}

