package lab3;

public class LinkedList <T> {
   protected Node<T> head;

   public LinkedList(){
       this.head = null; // При создании список пуст
   }

   public void append(T data){
       Node<T> newNode = new Node<>(data);
       Node<T> current = head;

       if (head == null){ // если первый элемент - просто вставляю как head и обновляю ссылку на next
           head = newNode;
           return;
       }

       while (current.next != null){ // Добавляю в конец списка и обновляю ссылку на next
           current = current.next;
       }
       current.next = newNode;
   }

   public void printList(){ // Метод для выводы элементов
       if (head == null){
           System.out.println("List is empty!");
           return;
       }
       Node<T> current = head;

       System.out.print("[");
       while (current.next != null){ // Прохожу по всем, пока не дойду до последнего элемента (null)
           System.out.print(current.data + ",");
           current = current.next;
       }
       System.out.println(current.data + "]");
   }

   public void delete(T data){ // Для удаления элемента
       Node<T> current = head;

       if (head == null) return; // Если список пуст

       if (head.data == data) {  // Если удаляемый элемент - head
           head = head.next;
           return;
       }

       while (current.next != null){ // Поиск и удаление элемента с обновлением ссылок
           if (current.next.data == data){ // если элемент найден - удаляю его, переопределяя ссылку предыдующего
               // на элемент, следующий за данным
               current.next = current.next.next;
               return;
           }
           current = current.next;
       }
       System.out.println("There is no such element");
   }

   public void addFirst(T data){ // Добавляю в начало и обновляю ссылку на голову
       Node<T> newNode = new Node<>(data);
       newNode.next = head;
       head = newNode;
   }

   public boolean find(T data){// Поиск элемнта по значению в списке
       Node<T> current = head;

       while (current != null){
           if (current.data == data)
               return true;
           current = current.next;
       } return false;
   }

   public int size(){ // Вычисляет длину списка
       Node<T> current = head;
       int count = 0;

       while(current != null){
           count++;
           current = current.next;
       } return count;
   }

   public boolean isEmpty(){ // Проверка на пустоту
       return head == null;
   }

   public void clear(){ // Очищаю список
       head = null;
   }
}

