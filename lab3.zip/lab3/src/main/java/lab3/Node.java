package lab3;

import java.util.Objects;

public class Node<T>{
    T data; // Добавляемые данные
    Node<T> next; // Ссылка на следующий элемент
    Node<T> previous; // Для двусвязного списка ссылка на пред.элемент

    public Node(T data){
        this.data = data;
        this.next = null;
        this.previous = null;

    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Node<?> node = (Node<?>) object;
        return Objects.equals(data, node.data) && Objects.equals(next, node.next) && Objects.equals(previous, node.previous);
    }

}